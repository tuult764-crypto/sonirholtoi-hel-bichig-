require('dotenv').config();
const express = require('express'), path = require('path'), crypto = require('crypto');
const { Pool, types } = require('pg'), bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), qpay = require('./qpay');
types.setTypeParser(20, Number);
const { JWT_SECRET, DATABASE_URL } = process.env, ADMIN_KEY = process.env.ADMIN_KEY || '';
// Тохиргоо дутуу байсан ч сайт (хуучин дэлгүүр) асна; зөвхөн шинэ /api хэсэг 503 өгнө
const CONFIG_OK = !!(JWT_SECRET && JWT_SECRET.length >= 24 && DATABASE_URL);
if (!JWT_SECRET || JWT_SECRET.length < 24) console.error('ТОХИРГОО ДУТУУ: JWT_SECRET (24+ тэмдэгт) тохируулна уу');
if (!DATABASE_URL) console.error('ТОХИРГОО ДУТУУ: DATABASE_URL тохируулна уу');
const pool = new Pool({ connectionString: DATABASE_URL, max: 5, connectionTimeoutMillis: 10000, ssl: process.env.PGSSL === 'disable' ? false : { rejectUnauthorized: false } });
const q = (t, p) => pool.query(t, p), SECURE = !!process.env.RENDER || process.env.NODE_ENV === 'production';
const IMG = ['image/jpeg', 'image/png', 'image/webp'], esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function init() {
  await q(`
CREATE TABLE IF NOT EXISTS shop_users(id BIGSERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL DEFAULT '', pass_hash TEXT NOT NULL, created_at BIGINT NOT NULL);
CREATE TABLE IF NOT EXISTS shop_materials(id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Бусад', price INTEGER NOT NULL DEFAULT 0, active BOOLEAN NOT NULL DEFAULT true, created_at BIGINT NOT NULL);
CREATE TABLE IF NOT EXISTS shop_files(id BIGSERIAL PRIMARY KEY, material_id BIGINT NOT NULL REFERENCES shop_materials(id) ON DELETE CASCADE, role TEXT NOT NULL, ord INTEGER NOT NULL DEFAULT 0, mime TEXT NOT NULL, data BYTEA NOT NULL);
CREATE INDEX IF NOT EXISTS files_m ON shop_files(material_id, role, ord);
CREATE TABLE IF NOT EXISTS shop_purchases(user_id BIGINT NOT NULL REFERENCES shop_users(id), material_id BIGINT NOT NULL REFERENCES shop_materials(id) ON DELETE CASCADE, created_at BIGINT NOT NULL, PRIMARY KEY(user_id, material_id));
CREATE TABLE IF NOT EXISTS shop_payments(id BIGSERIAL PRIMARY KEY, order_no TEXT UNIQUE NOT NULL, user_id BIGINT NOT NULL REFERENCES shop_users(id), material_id BIGINT NOT NULL REFERENCES shop_materials(id) ON DELETE CASCADE, invoice_id TEXT NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at BIGINT NOT NULL, paid_at BIGINT);`);
}
const app = express();
app.set('trust proxy', 1);
// Нууц файлуудыг (код, тохиргоо, өгөгдөл) нийтэд нээхгүй
const DENY = /^\/(server\.js|qpay\.js|package(-lock)?\.json|\.env.*|\.git.*|netlify.*|readme\.md|literature_db\.txt|node_modules.*|.*\.xlsx)$/i;
app.use((req, res, next) => { let p = ''; try { p = decodeURIComponent(req.path); } catch { return res.status(400).end(); } DENY.test(p) ? res.status(404).end() : next(); });
app.use((req, res, next) => (req.path === '/api/admin/materials' || req.path === '/api/lesson-plan') && req.method === 'POST' ? next() : express.json({ limit: '100kb' })(req, res, next));
let ready = false;
app.use('/api', (req, res, next) => (ready || req.path === '/lesson-plan') ? next() : res.status(503).json({ error: 'Систем бэлдэж байна. Түр хүлээгээд дахин оролдоно уу.' }));
const ah = fn => (req, res, next) => fn(req, res, next).catch(e => { console.error(req.path, e.message); if (!res.headersSent) res.status(500).json({ error: 'Серверийн алдаа' }); });
const hits = new Map();
const limit = (max, ms) => (req, res, next) => { const k = req.ip + req.path, now = Date.now(), a = (hits.get(k) || []).filter(t => now - t < ms); if (a.length >= max) return res.status(429).json({ error: 'Хэт олон оролдлого. Түр хүлээнэ үү.' }); a.push(now); hits.set(k, a); next(); };
setInterval(() => { const n = Date.now(); for (const [k, a] of hits) if (!a.some(t => n - t < 3600e3)) hits.delete(k); }, 600e3).unref();

// ---- хэрэглэгч, session (httpOnly cookie) ----
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim()).filter(Boolean).map(c => { const i = c.indexOf('='); return [c.slice(0, i), decodeURIComponent(c.slice(i + 1))]; }));
const pub = u => ({ id: u.id, email: u.email, name: u.name });
const login = (res, u) => res.cookie('sid', jwt.sign({ uid: u.id }, JWT_SECRET, { expiresIn: '60d' }), { httpOnly: true, sameSite: 'lax', secure: SECURE, maxAge: 60 * 864e5 });
async function userOf(req) { try { return (await q('SELECT * FROM shop_users WHERE id=$1', [jwt.verify(cookies(req).sid, JWT_SECRET).uid])).rows[0] || null; } catch { return null; } }
const need = ah(async (req, res, next) => { req.user = await userOf(req); req.user ? next() : res.status(401).json({ error: 'Нэвтэрнэ үү' }); });
app.post('/api/auth/register', limit(10, 3600e3), ah(async (req, res) => {
  const email = String(req.body.email || '').toLowerCase().trim(), pw = String(req.body.password || ''), name = String(req.body.name || '').trim().slice(0, 60);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || pw.length < 8 || pw.length > 200) return res.status(400).json({ error: 'Зөв и-мэйл, 8+ тэмдэгт нууц үг оруулна уу' });
  try { const u = (await q('INSERT INTO shop_users(email,name,pass_hash,created_at) VALUES($1,$2,$3,$4) RETURNING *', [email, name, bcrypt.hashSync(pw, 10), Date.now()])).rows[0]; login(res, u); res.json({ user: pub(u) }); }
  catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'Энэ и-мэйл бүртгэлтэй байна' }); throw e; }
}));
app.post('/api/auth/login', limit(20, 900e3), ah(async (req, res) => {
  const u = (await q('SELECT * FROM shop_users WHERE email=$1', [String(req.body.email || '').toLowerCase().trim()])).rows[0];
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.pass_hash)) return res.status(401).json({ error: 'И-мэйл эсвэл нууц үг буруу' });
  login(res, u); res.json({ user: pub(u) });
}));
app.post('/api/auth/logout', (req, res) => { res.clearCookie('sid'); res.json({ ok: true }); });
app.get('/api/auth/me', ah(async (req, res) => { const u = await userOf(req); res.json({ user: u ? pub(u) : null }); }));

// ---- материал, эрх ----
const owned = async (m, u) => m.price === 0 || (!!u && (await q('SELECT 1 FROM shop_purchases WHERE user_id=$1 AND material_id=$2', [u.id, m.id])).rowCount > 0);
const material = async id => (await q('SELECT * FROM shop_materials WHERE id=$1 AND active=true', [parseInt(id) || 0])).rows[0];
app.get('/api/materials', ah(async (req, res) => {
  const u = await userOf(req), mine = u ? new Set((await q('SELECT material_id FROM shop_purchases WHERE user_id=$1', [u.id])).rows.map(r => r.material_id)) : new Set();
  const rows = (await q('SELECT id,title,description,category,price,created_at FROM shop_materials WHERE active=true ORDER BY created_at DESC')).rows;
  res.json(rows.map(m => ({ ...m, owned: m.price === 0 || mine.has(m.id) })));
}));
app.get('/api/my', need, ah(async (req, res) => res.json((await q('SELECT m.id,m.title,m.description,m.category,m.price,p.created_at "boughtAt" FROM shop_purchases p JOIN shop_materials m ON m.id=p.material_id WHERE p.user_id=$1 AND m.active=true ORDER BY p.created_at DESC', [req.user.id])).rows)));
const sendFile = (res, f) => { res.set({ 'Content-Type': f.mime, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline' }); res.send(f.data); };
app.get('/api/materials/:id/cover', ah(async (req, res) => {
  const f = (await q("SELECT f.mime,f.data FROM shop_files f JOIN shop_materials m ON m.id=f.material_id WHERE m.id=$1 AND m.active=true AND f.role='cover' LIMIT 1", [parseInt(req.params.id) || 0])).rows[0];
  if (!f) return res.status(404).end(); res.set('Cache-Control', 'public, max-age=300'); res.set('Content-Type', f.mime); res.send(f.data);
}));
// хуудас бүрийг эрх шалгаж өгнө (нийтэд нээлттэй URL биш)
app.get('/api/materials/:id/page/:n', ah(async (req, res) => {
  const m = await material(req.params.id); if (!m) return res.status(404).end();
  if (!(await owned(m, await userOf(req)))) return res.status(403).end();
  const f = (await q("SELECT mime,data FROM shop_files WHERE material_id=$1 AND role='page' ORDER BY ord OFFSET $2 LIMIT 1", [m.id, Math.max(0, (parseInt(req.params.n) || 1) - 1)])).rows[0];
  f ? sendFile(res, f) : res.status(404).end();
}));
app.get('/api/materials/:id/print', ah(async (req, res) => {
  const m = await material(req.params.id), u = await userOf(req); res.set('Cache-Control', 'no-store');
  const msg = t => res.status(403).type('html').send(`<meta charset="utf-8"><body style="font:18px system-ui;padding:40px;text-align:center">${t}<p><a href="/materials.html">← Сургалтын материал</a></p>`);
  if (!m) return res.status(404).type('html').send('<meta charset="utf-8">Материал олдсонгүй');
  if (!(await owned(m, u))) return msg(u ? 'Энэ материалыг хэвлэхийн тулд эхлээд худалдаж авна уу.' : 'Төлбөртэй материал. Эхлээд нэвтэрч, худалдаж авна уу.');
  const n = (await q("SELECT COUNT(*) c FROM shop_files WHERE material_id=$1 AND role='page'", [m.id])).rows[0].c;
  if (!n) return msg('Энэ материалын хуудас хараахан нэмэгдээгүй байна.');
  const imgs = Array.from({ length: n }, (_, i) => `<img class="pg" alt="Хуудас ${i + 1}" src="/api/materials/${m.id}/page/${i + 1}">`).join('');
  res.type('html').send(`<!doctype html><html lang="mn"><meta charset="utf-8"><title>${esc(m.title)}</title><style>@page{size:A4;margin:8mm}body{margin:0;background:#eee;font-family:system-ui}.bar{position:sticky;top:0;background:#fff;padding:10px;text-align:center;box-shadow:0 1px 6px #0002}.bar button{font:700 16px system-ui;padding:10px 22px;border:0;border-radius:10px;background:#b8763f;color:#fff;cursor:pointer}.pg{display:block;margin:10px auto;max-width:100%;background:#fff}@media print{.bar{display:none}body{background:#fff}.pg{margin:0;width:100%;page-break-after:always;break-after:page}}</style><div class="bar"><button onclick="print()">🖨️ Хэвлэх</button></div>${imgs}<script>let k=0;document.querySelectorAll('.pg').forEach(i=>i.complete?k++:i.onload=()=>{if(++k===${n})setTimeout(print,300)});if(k===${n})setTimeout(print,300)</script></html>`);
}));

// ---- худалдан авалт, төлбөр (QPay / гар баталгаажуулалт) ----
async function activate(orderNo) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const p = await c.query("UPDATE shop_payments SET status='paid', paid_at=$2 WHERE order_no=$1 AND status='pending' RETURNING user_id, material_id", [orderNo, Date.now()]);
    if (!p.rowCount) { await c.query('ROLLBACK'); return false; }
    await c.query('INSERT INTO shop_purchases(user_id,material_id,created_at) VALUES($1,$2,$3) ON CONFLICT DO NOTHING', [p.rows[0].user_id, p.rows[0].material_id, Date.now()]);
    await c.query('COMMIT'); return true;
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
}
async function verify(orderNo) {
  const p = (await q('SELECT * FROM shop_payments WHERE order_no=$1', [orderNo])).rows[0];
  if (!p) return 'unknown'; if (p.status === 'paid') return 'paid';
  if (await qpay.isPaid(p.invoice_id, p.amount)) { await activate(orderNo); return 'paid'; }
  return 'pending';
}
app.post('/api/buy', need, limit(30, 3600e3), ah(async (req, res) => {
  const m = await material(req.body.materialId);
  if (!m) return res.status(404).json({ error: 'Материал олдсонгүй' });
  if (m.price === 0) return res.status(400).json({ error: 'Үнэгүй материал. Шууд хэвлэж болно.' });
  if (await owned(m, req.user)) return res.status(409).json({ error: 'Та энэ материалыг аль хэдийн авсан байна (Миний сан)' });
  const manual = qpay.MODE === 'manual';
  for (let i = 0; i < 3; i++) {
    const orderNo = manual ? 'BT' + crypto.randomInt(10000, 100000) : 'BT' + Date.now() + crypto.randomBytes(3).toString('hex');
    try {
      const inv = await qpay.createInvoice({ orderNo, amount: m.price, description: m.title.slice(0, 80) });
      await q('INSERT INTO shop_payments(order_no,user_id,material_id,invoice_id,amount,created_at) VALUES($1,$2,$3,$4,$5,$6)', [orderNo, req.user.id, m.id, inv.invoiceId, m.price, Date.now()]);
      return res.json({ orderNo, amount: m.price, ...inv, mock: qpay.MODE === 'mock', manual, qrUrl: manual ? '/qr.png' : null });
    } catch (e) { if (e.code !== '23505') { console.error('buy:', e.message); return res.status(502).json({ error: 'Нэхэмжлэх үүсгэж чадсангүй. Дахин оролдоно уу.' }); } }
  }
  res.status(500).json({ error: 'Дахин оролдоно уу' });
}));
app.post('/api/pay/check', need, ah(async (req, res) => {
  const p = (await q('SELECT 1 FROM shop_payments WHERE order_no=$1 AND user_id=$2', [String(req.body.orderNo || ''), req.user.id])).rows[0];
  if (!p) return res.status(404).json({ error: 'Олдсонгүй' });
  try { res.json({ status: await verify(String(req.body.orderNo)) }); } catch (e) { console.error('check:', e.message); res.status(502).json({ error: 'Төлбөр шалгаж чадсангүй' }); }
}));
app.all('/api/pay/callback', async (req, res) => { try { await verify(String(req.query.order || '')); } catch {} res.sendStatus(200); });

// ---- админ (/admin): ADMIN_KEY-ээр хамгаалагдсан, сервер талд шалгана ----
const adminAuth = (req, res, next) => {
  const a = Buffer.from(String(req.headers['x-admin-key'] || '')), b = Buffer.from(ADMIN_KEY);
  if (ADMIN_KEY.length < 12 || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Админ түлхүүр буруу' });
  next();
};
const A = [limit(120, 900e3), adminAuth];
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'admin.html')));
app.get('/api/admin/pending', ...A, ah(async (req, res) => res.json((await q(`SELECT p.order_no "orderNo", p.amount, p.created_at "createdAt", u.email, m.title FROM shop_payments p JOIN shop_users u ON u.id=p.user_id JOIN shop_materials m ON m.id=p.material_id WHERE p.status='pending' AND p.invoice_id LIKE 'MANUAL-%' ORDER BY p.created_at DESC LIMIT 100`)).rows)));
app.post('/api/admin/confirm', ...A, ah(async (req, res) => {
  const o = String(req.body.orderNo || '');
  if (!(await q("SELECT 1 FROM shop_payments WHERE order_no=$1 AND invoice_id LIKE 'MANUAL-%'", [o])).rowCount) return res.status(404).json({ error: 'Олдсонгүй' });
  res.json({ ok: true, activated: await activate(o) });
}));
app.get('/api/admin/materials', ...A, ah(async (req, res) => res.json((await q(`SELECT m.id,m.title,m.description,m.category,m.price,m.active,(SELECT COUNT(*) FROM shop_files f WHERE f.material_id=m.id AND f.role='page') pages,(SELECT COUNT(*) FROM shop_purchases p WHERE p.material_id=m.id) sold FROM shop_materials m ORDER BY m.created_at DESC`)).rows)));
const b64 = f => { const m = String((f && f.mime) || ''), d = String((f && f.data) || '').replace(/^data:[^,]*,/, ''); return IMG.includes(m) && /^[A-Za-z0-9+/=]+$/.test(d) && d.length > 20 ? { mime: m, data: Buffer.from(d, 'base64') } : null; };
const fields = b => ({ title: String(b.title || '').trim().slice(0, 120), description: String(b.description || '').trim().slice(0, 600), category: String(b.category || 'Бусад').trim().slice(0, 40) || 'Бусад', price: Math.max(0, Math.min(1e6, parseInt(b.price) || 0)) });
app.post('/api/admin/materials', ...A, express.json({ limit: '30mb' }), ah(async (req, res) => {
  const f = fields(req.body), pages = (Array.isArray(req.body.pages) ? req.body.pages : []).slice(0, 40).map(b64), cover = b64(req.body.cover);
  if (!f.title || pages.some(p => !p) || (!cover && !pages.length)) return res.status(400).json({ error: 'Нэр, зураг (JPG/PNG/WEBP) зөв оруулна уу' });
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const id = (await c.query('INSERT INTO shop_materials(title,description,category,price,created_at) VALUES($1,$2,$3,$4,$5) RETURNING id', [f.title, f.description, f.category, f.price, Date.now()])).rows[0].id;
    const cv = cover || pages[0];
    await c.query("INSERT INTO shop_files(material_id,role,ord,mime,data) VALUES($1,'cover',0,$2,$3)", [id, cv.mime, cv.data]);
    for (let i = 0; i < pages.length; i++) await c.query("INSERT INTO shop_files(material_id,role,ord,mime,data) VALUES($1,'page',$2,$3,$4)", [id, i, pages[i].mime, pages[i].data]);
    await c.query('COMMIT'); res.json({ ok: true, id });
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
}));
app.post('/api/admin/materials/:id', ...A, ah(async (req, res) => {
  const f = fields(req.body), active = req.body.active !== false;
  if (!f.title) return res.status(400).json({ error: 'Нэр хоосон байна' });
  res.json({ ok: (await q('UPDATE shop_materials SET title=$2,description=$3,category=$4,price=$5,active=$6 WHERE id=$1', [parseInt(req.params.id) || 0, f.title, f.description, f.category, f.price, active])).rowCount === 1 });
}));

// ---- Ээлжит хичээлийн төлөвлөлт (сурах бичгийн зураг/эхээс AI боловсруулна) ----
const lesson = require('./lesson-core');
const LESSON_MODEL = process.env.LESSON_MODEL || 'gpt-4o';
const LESSON_DAILY_CAP = parseInt(process.env.LESSON_DAILY_CAP) || 150; // өдөрт нийт хэдэн удаа AI дуудахыг хязгаарлана (зардлаас хамгаална)
let lessonDay = '', lessonCount = 0;
const IMG_URL = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
const LESSON_SYS = `Та Монгол Улсын ерөнхий боловсролын сургуулийн туршлагатай багш, арга зүйч. Багшийн өгсөн сурах бичгийн хуудасны зураг, эх, ангийн түвшин, хичээлийн хугацаанд тулгуурлан "Ээлжит хичээлийн төлөвлөлт" боловсруулна. Хариуг ЗӨВХӨН нэг JSON объект байдлаар, монгол хэлээр (кирилл) бич. JSON-оос өөр текст бүү нэм.

ДҮРЭМ:
1. Сурах бичгийн эх, асуулт, дасгалыг зурагнаас болон өгсөн эхээс уншиж, төлөвлөгөөг тэдгээрт тулгуурла. Дасгал, даалгаврын дугаар, гарчгийг зөв иш татаж болно. Зурагнаас уншигдаагүй, мэдэгдэхгүй зүйлийг зохиож бүү нэм; уншигдахгүй хэсэг байвал "warnings" талбарт товч бич.
2. Алхмын тоог хичээлийн зорилго, агуулга, ангийн нас, хугацаа, арга, ажлын зохион байгуулалтаас хамааруулан өөрөө тогтоо. Заавал 11 алхамтай байх албагүй; 6, 8, 10, 12 эсвэл түүнээс олон байж болно. Алхам олшруулахын тулд агуулгыг давтах, шаардлагагүй үйл ажиллагаа зохиохыг хориглоно.
3. "stages" нь яг 3 үе шат: Эхлэл, Өрнөл, Төгсгөл. Бүх алхмын "minutes" (бүхэл тоо)-ын нийлбэр нийт хугацаатай яг тэнцүү байх ёстой. Үе шатны хугацаа хичээлийн онцлогт тохирно (ихэвчлэн эхлэл, төгсгөл тус бүр ойролцоогоор 10–15%).
4. Алхам бүрд: title (нэр), minutes, goal (зорилго), teacher (багшийн хийх үйл ажиллагаа), student (сурагчийн хийх үйл ажиллагаа), materials (хэрэглэгдэхүүн, байхгүй бол ""), result (үнэлгээний арга эсвэл хүлээгдэх үр дүн). Багшийн болон сурагчийн үйл ажиллагаа бие биедээ яг харгалзсан байна. Тодорхой, хэрэгжихүйц бич (teacher, student тус бүр 2–4 өгүүлбэр).
5. Хичээл нь өмнөх мэдлэгийг идэвхжүүлэх, шинэ агуулгыг бие даан болон хамтран ойлгох, хэрэглэх (дасгал, даалгавар), дүгнэж үнэлэх үе шатуудыг агуулсан байна. Ганцаарчилсан, хосын, багийн ажлыг агуулгад тохируулан хослуул.
6. objectives нь 3–5 хэмжигдэхүйц зорилт ("...ж чадна" хэлбэртэй). goal нь нэг өгүүлбэр.
7. Багш сургалтын арга заасан бол түүнийг ашигла; заагаагүй бол агуулгад тохирох 3–5 аргыг өөрөө сонго.
8. assessment: 2–4 мөр — явцын үнэлгээ ба гүйцэтгэлийн үнэлгээний шалгуур (оноо эсвэл түвшинтэй).
9. homework: сурах бичгийн агуулгатай холбоотой, 10 минутад хийхээр нэг даалгавар.
10. Багш хичээлийн сэдэв өгөөгүй бол "lessonTopic"-ийг сурах бичгийн агуулгаас тодорхойл.

JSON БҮТЭЦ:
{"lessonTopic":"","unitTopic":"","organization":["Хичээлийн төрөл: ...","Ажлын хэлбэр: ..."],"methods":[""],"goal":"","objectives":[""],"materials":[""],"stages":[{"name":"Эхлэл","steps":[{"title":"","minutes":5,"goal":"","teacher":"","student":"","materials":"","result":""}]},{"name":"Өрнөл","steps":[]},{"name":"Төгсгөл","steps":[]}],"homework":"","assessment":[""],"warnings":[]}`;
app.post('/api/lesson-plan', limit(8, 3600e3), express.json({ limit: '25mb' }), ah(async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'AI хараахан тохируулагдаагүй байна (OPENAI_API_KEY).' });
  const b = req.body || {}, t = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
  const images = (Array.isArray(b.images) ? b.images : []).slice(0, 6), text = t(b.text, 12000);
  if (images.some(u => typeof u !== 'string' || u.length > 7e6 || !IMG_URL.test(u))) return res.status(400).json({ error: 'Зураг JPG/PNG/WEBP байх ёстой' });
  if (!images.length && text.length < 30) return res.status(400).json({ error: 'Сурах бичгийн зураг эсвэл эхийг оруулна уу' });
  const minutes = Math.max(10, Math.min(240, parseInt(b.minutes) || 40));
  const inp = { grade: t(b.grade, 30), subject: t(b.subject, 60) || 'Монгол хэл', lessonTopic: t(b.lessonTopic, 250), unitTopic: t(b.unitTopic, 200), method: t(b.method, 300), minutes };
  const today = new Date().toISOString().slice(0, 10);
  if (today !== lessonDay) { lessonDay = today; lessonCount = 0; }
  if (lessonCount >= LESSON_DAILY_CAP) return res.status(429).json({ error: 'Өнөөдрийн хязгаар хэтэрлээ. Маргааш дахин оролдоно уу.' });
  lessonCount++;
  const info = `Анги: ${inp.grade || '(заагаагүй)'}\nСудлагдахуун: ${inp.subject}\nНийт хугацаа: ${minutes} минут (алхмуудын минутын нийлбэр яг ${minutes} байна)\nХичээлийн сэдэв: ${inp.lessonTopic || '(өгөөгүй — сурах бичгээс тодорхойл)'}\nНэгжийн сэдэв: ${inp.unitTopic || '(өгөөгүй)'}\nСургалтын арга: ${inp.method || '(өгөөгүй — өөрөө сонго)'}\n` +
    (text ? `\nСурах бичгийн эх (багшийн оруулсан):\n${text}\n` : '') + (images.length ? `\nДараах ${images.length} зураг нь сурах бичгийн хуудас.` : '');
  const content = [{ type: 'text', text: info }, ...images.map(u => ({ type: 'image_url', image_url: { url: u, detail: 'high' } }))];
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 150e3);
  let r, data;
  try {
    r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + process.env.OPENAI_API_KEY },
      body: JSON.stringify({ model: LESSON_MODEL, temperature: 0.4, max_tokens: 6000, response_format: { type: 'json_object' }, messages: [{ role: 'system', content: LESSON_SYS }, { role: 'user', content }] })
    });
    data = await r.json().catch(() => ({}));
  } catch (e) {
    return res.status(e.name === 'AbortError' ? 504 : 502).json({ error: 'AI хариулахад хэт удлаа. Дахин оролдоно уу.' });
  } finally { clearTimeout(timer); }
  if (!r.ok) { console.error('lesson-plan OpenAI:', r.status, data && data.error && data.error.message); return res.status(502).json({ error: 'AI үйлчилгээ хариулсангүй. Түр хүлээгээд дахин оролдоно уу.' }); }
  let raw; try { raw = JSON.parse(data.choices[0].message.content); } catch { return res.status(502).json({ error: 'AI-ийн хариуг уншиж чадсангүй. Дахин оролдоно уу.' }); }
  const plan = lesson.sanitizePlan(raw, { totalMinutes: minutes, grade: inp.grade, subject: inp.subject, lessonTopic: inp.lessonTopic, unitTopic: inp.unitTopic });
  if (lesson.allSteps(plan).length < 3) return res.status(502).json({ error: 'AI бүрэн төлөвлөгөө гаргаж чадсангүй. Дахин оролдоно уу.' });
  res.json({ plan, warnings: (Array.isArray(raw.warnings) ? raw.warnings : []).slice(0, 5).map(w => t(w, 200)).filter(Boolean) });
}));

app.use(express.static(path.join(__dirname)));
app.listen(process.env.PORT || 3000, () => console.log('Ажиллаж байна. Port:', process.env.PORT || 3000, '| QPay горим:', qpay.MODE));
(async function boot() {
  if (!CONFIG_OK) return;
  for (;;) {
    try { await init(); ready = true; console.log('Өгөгдлийн сан бэлэн'); return; }
    catch (e) { console.error('Өгөгдлийн сантай холбогдож чадсангүй:', e.message, '(15 секундын дараа дахин оролдоно)'); await new Promise(r => setTimeout(r, 15000)); }
  }
})();
