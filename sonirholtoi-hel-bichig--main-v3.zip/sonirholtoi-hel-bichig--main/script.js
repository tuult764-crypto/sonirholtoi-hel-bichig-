/* ════════════════════════════════════
   CONSTANTS & STATE
════════════════════════════════════ */
const AUTH_KEY   = 'shb_auth_v2';
const MONG_NUMS  = {'1':'᠑','2':'᠒','3':'᠓','4':'᠔','5':'᠕','6':'᠖','7':'᠗','8':'᠘','9':'᠙'};
const MONG_REV   = Object.fromEntries(Object.entries(MONG_NUMS).map(([k,v])=>[v,k]));
const GAS_URL    = 'https://script.google.com/macros/s/AKfycby1Hsa1TvOLBeuLuHtMTzYfuE8i6HT6fRxfhZqYcXB7tGSnt6-61sPQLwdulKhqf6FldQ/exec';
const SHEET_ID   = '19XbGi1hWULDm2MRjFAG8G0dtlp7tbfN2pJSupKWA6G4';
const SHEET_NAME = 'Products';

let currentUser    = '';
let cartItems      = [];
let authTab        = 'login';
let allProducts    = [];
let sudokuSolution = [];
let sudokuPuzzle   = [];
let _spBuying      = {pages:0,price:0};
let _currentCourseType = '';

/* ════════════════════════════════════
   INIT
════════════════════════════════════ */
/* ════════════════════════════════════
   LOGO — GitHub-аас найдвартай ачаалах
════════════════════════════════════ */
const LOGO_URL = 'https://raw.githubusercontent.com/tuult764-crypto/sonirholtoi-hel-bichig-/main/logo.png';

// Лого ачааллагдахгүй бол дахин оролдоно (3 удаа)
function loadLogoWithRetry(imgEl, attempt) {
  if (!imgEl) return;
  attempt = attempt || 1;
  const ts = Date.now();
  const url = LOGO_URL + '?v=' + ts;

  imgEl.onload = function() {
    imgEl.style.display = 'block';
  };
  imgEl.onerror = function() {
    if (attempt < 3) {
      setTimeout(() => loadLogoWithRetry(imgEl, attempt + 1), 1500);
    } else {
      handleLogoError(imgEl);
    }
  };
  imgEl.src = url;
}

function handleLogoError(imgEl) {
  // Зураг олдохгүй бол emoji fallback
  const wrap = imgEl.parentElement;
  if (!wrap) return;
  const size = imgEl.id === 'navLogo' ? '20px' : '18px';
  imgEl.style.display = 'none';
  if (!wrap.querySelector('.logo-fallback')) {
    const span = document.createElement('span');
    span.className = 'logo-fallback';
    span.style.cssText = `font-size:${size};line-height:1`;
    span.textContent = '📖';
    wrap.appendChild(span);
  }
}

document.addEventListener('DOMContentLoaded',()=>{
  // Лого зургуудыг retry-тай ачаална
  const navLogo    = document.getElementById('navLogo');
  const footerLogo = document.getElementById('footerLogo');
  if (navLogo)    loadLogoWithRetry(navLogo,    1);
  if (footerLogo) loadLogoWithRetry(footerLogo, 1);

  const saved = localStorage.getItem(AUTH_KEY);
  currentUser = saved || '';
  updateNavUser();
  loadProducts();
  initSudoku();
  updatePrintUI();
});

/* ════════════════════════════════════
   NAVIGATION
════════════════════════════════════ */
function showSec(name){
  document.querySelectorAll('.sec').forEach(s=>s.classList.remove('active'));
  const el=document.getElementById(name+'Section');
  if(el){el.classList.add('active');window.scrollTo(0,0);}
  // Цэсний идэвхтэй товч: хуудас бүр цэсний аль хэсэгт хамаарахыг заана
  const navOf={home:'home',knowledge:'knowledge',training:'students',worksheet:'teachers',games:'games',sudoku:'games',shop:'library',library:'more',about:'more'};
  const key=navOf[name];
  document.querySelectorAll('.nav-btn[data-nav]').forEach(b=>{
    const on=b.dataset.nav===key;
    b.classList.toggle('active',on);
    if(on)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
  });
  closeNavMore();
  if(name==='library')loadLibrary();
  if(name==='sudoku')updatePrintUI();
  if(name==='home'&&window.HomeProgress){HomeProgress.render();if(window.KnowledgePage)KnowledgePage.refresh();}
}
// "Бусад" цэс
function closeNavMore(){const m=document.getElementById('navMore');if(m){m.classList.remove('open');const b=m.querySelector('.nav-btn');if(b)b.setAttribute('aria-expanded','false');}}
function toggleNavMore(e){
  if(e)e.stopPropagation();
  const m=document.getElementById('navMore');if(!m)return;
  const open=m.classList.toggle('open');
  m.querySelector('.nav-btn').setAttribute('aria-expanded',open?'true':'false');
}
document.addEventListener('click',e=>{const m=document.getElementById('navMore');if(m&&!m.contains(e.target))closeNavMore();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeNavMore();});
document.addEventListener('DOMContentLoaded',()=>{const b=document.querySelector('.nav-btn[data-nav="home"]');if(b){b.classList.add('active');b.setAttribute('aria-current','page');}});

/* ════════════════════════════════════
   AUTH — Нэвтрэх / Бүртгүүлэх / Avatar
════════════════════════════════════ */
const USERS_KEY   = 'shb_users_v1';
const AVATAR_KEY  = 'shb_avatar_v1';

// DiceBear avatar seeds — 20 сонголт
const AVATAR_SEEDS = [
  'Tuul','Oyun','Bat','Khuu','Deli','Mogi','Naran','Saran',
  'Gal','Tenger','Urd','Zuun','Barun','Umar','Gobi',
  'Khar','Tsagaan','Ulaan','Nogoon','Khukh'
];
const AVATAR_STYLES = [
  'avataaars','bottts','fun-emoji','pixel-art','adventurer',
  'lorelei','notionists','open-peeps','personas','croodles'
];

function getAvatarUrl(seed, style='avataaars') {
  return `https://api.dicebear.com/7.x/${style}/svg?seed=${encodeURIComponent(seed)}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf`;
}

function getSavedUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY)||'{}'); } catch{ return {}; }
}
function saveUser(email, data) {
  const users = getSavedUsers();
  users[email] = {...(users[email]||{}), ...data};
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}
function getUser(email) {
  return getSavedUsers()[email] || null;
}

// ── Open/Close ──────────────────────
function openAuth(tab='login') {
  switchTab(tab);
  clearAuthMessages();
  document.getElementById('authModal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}
function closeAuth() {
  document.getElementById('authModal').classList.add('hidden');
  document.body.style.overflow = '';
}

function switchTab(tab) {
  authTab = tab;
  const isLogin = tab === 'login';
  document.getElementById('tabLogin').classList.toggle('active', isLogin);
  document.getElementById('tabReg').classList.toggle('active', !isLogin);
  document.getElementById('loginFields').style.display = isLogin ? '' : 'none';
  document.getElementById('regFields').style.display   = isLogin ? 'none' : '';
  clearAuthMessages();
  if (!isLogin) buildRegAvatarGrid();
}

function showAuthError(msg) {
  const el = document.getElementById('authError');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('authSuccess').style.display = 'none';
}
function showAuthSuccess(msg) {
  const el = document.getElementById('authSuccess');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('authError').style.display = 'none';
}
function clearAuthMessages() {
  document.getElementById('authError').style.display = 'none';
  document.getElementById('authSuccess').style.display = 'none';
}

// ── Login ───────────────────────────
function handleAuth() {
  const email = document.getElementById('authEmail').value.trim().toLowerCase();
  const pass  = document.getElementById('authPass').value;
  if (!email || !email.includes('@')) { showAuthError('Зөв и-мэйл хаяг оруулна уу.'); return; }
  if (pass.length < 6) { showAuthError('Нууц үг хамгийн багадаа 6 тэмдэгт байна.'); return; }

  const user = getUser(email);
  if (!user) { showAuthError('И-мэйл бүртгэлгүй байна. Бүртгүүлнэ үү.'); return; }
  if (user.pass !== btoa(pass)) { showAuthError('Нууц үг буруу байна.'); return; }

  loginSuccess(email, user);
}

// ── Register ────────────────────────
let _selectedRegAvatar = AVATAR_SEEDS[0];
let _selectedRegStyle  = AVATAR_STYLES[0];

function buildRegAvatarGrid() {
  const grid = document.getElementById('regAvatarGrid');
  if (!grid || grid.children.length) return; // already built
  AVATAR_SEEDS.slice(0,10).forEach((seed,i) => {
    const style = AVATAR_STYLES[i % AVATAR_STYLES.length];
    const div = document.createElement('div');
    div.style.cssText = 'border-radius:12px;border:2.5px solid var(--border);cursor:pointer;overflow:hidden;aspect-ratio:1;background:var(--surface2);transition:all .18s';
    div.onclick = () => {
      document.querySelectorAll('#regAvatarGrid > div').forEach(d => {
        d.style.borderColor = 'var(--border)'; d.style.transform = '';
      });
      div.style.borderColor = 'var(--amber)';
      div.style.transform = 'scale(1.08)';
      _selectedRegAvatar = seed; _selectedRegStyle = style;
    };
    const img = document.createElement('img');
    img.src = getAvatarUrl(seed, style);
    img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block';
    div.appendChild(img);
    grid.appendChild(div);
    if (i === 0) { div.style.borderColor = 'var(--amber)'; div.style.transform = 'scale(1.08)'; }
  });
}

function handleRegister() {
  const name  = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pass  = document.getElementById('regPass').value;
  const pass2 = document.getElementById('regPass2').value;

  if (!name)                       { showAuthError('Нэрээ оруулна уу.'); return; }
  if (!email.includes('@'))        { showAuthError('Зөв и-мэйл хаяг оруулна уу.'); return; }
  if (pass.length < 6)             { showAuthError('Нууц үг хамгийн багадаа 6 тэмдэгт байна.'); return; }
  if (pass !== pass2)              { showAuthError('Нууц үг тохирохгүй байна.'); return; }
  if (getUser(email))              { showAuthError('Энэ и-мэйл аль хэдийн бүртгэлтэй байна.'); return; }

  saveUser(email, {
    name, pass: btoa(pass),
    avatarSeed: _selectedRegAvatar,
    avatarStyle: _selectedRegStyle,
    createdAt: Date.now()
  });
  showAuthSuccess('✅ Бүртгэл амжилттай! Нэвтэрч байна...');
  setTimeout(() => loginSuccess(email, getUser(email)), 1000);
}

function loginSuccess(email, user) {
  currentUser = email;
  localStorage.setItem(AUTH_KEY, email);
  // Save avatar preference
  if (user.avatarSeed) {
    localStorage.setItem(AVATAR_KEY, JSON.stringify({seed: user.avatarSeed, style: user.avatarStyle||'avataaars'}));
  }
  updateNavUser();
  closeAuth();
  showToast(`👋 Сайн байна уу, ${user.name || email.split('@')[0]}!`, 'success');
}

function logout() {
  localStorage.removeItem(AUTH_KEY);
  currentUser = '';
  updateNavUser();
  showToast('Гарлаа. Дараа уулзацгаая! 👋', 'success');
}

function handleForgot() {
  showAuthSuccess('📧 Нууц үг сэргээх холбоос тан руу илгээгдэх болно.');
}

// ── Nav user display ─────────────────
function updateNavUser() {
  const guest   = document.getElementById('navGuest');
  const pill    = document.getElementById('navUserPill');
  const avatarEl= document.getElementById('userAvatar');
  const labelEl = document.getElementById('userLabel');
  const nameEl  = document.getElementById('menuUserName');
  const emailEl = document.getElementById('menuUserEmail');

  if (currentUser && currentUser !== 'guest@shb.mn') {
    // Logged in
    if (guest) guest.style.display = 'none';
    if (pill)  pill.style.display  = 'flex';

    const user = getUser(currentUser) || {};
    const saved = (() => { try { return JSON.parse(localStorage.getItem(AVATAR_KEY)||'null'); } catch{ return null; } })();
    const seed  = saved?.seed  || user.avatarSeed  || currentUser.split('@')[0];
    const style = saved?.style || user.avatarStyle || 'avataaars';

    if (avatarEl) { avatarEl.src = getAvatarUrl(seed, style); }
    if (labelEl)  { labelEl.textContent = (user.name || currentUser.split('@')[0]).substring(0,12); }
    if (nameEl)   { nameEl.textContent  = user.name || currentUser.split('@')[0]; }
    if (emailEl)  { emailEl.textContent = currentUser; }
  } else {
    // Guest
    if (guest) guest.style.display = 'flex';
    if (pill)  pill.style.display  = 'none';
  }
}

// ── Avatar picker (profile edit) ─────
let _pickerSelected = null;

function openAvatarPicker(e) {
  if (e) e.stopPropagation();
  const grid = document.getElementById('avatarGrid');
  if (!grid) return;

  // Get current
  const saved = (() => { try { return JSON.parse(localStorage.getItem(AVATAR_KEY)||'null'); } catch{ return null; } })();
  const curSeed  = saved?.seed  || 'default';
  const curStyle = saved?.style || 'avataaars';
  _pickerSelected = { seed: curSeed, style: curStyle };

  // Build grid: 4 styles × 5 seeds = 20 options
  grid.innerHTML = '';
  const picks = [];
  AVATAR_STYLES.slice(0,4).forEach(style => {
    AVATAR_SEEDS.slice(0,5).forEach(seed => picks.push({seed, style}));
  });

  picks.forEach(({seed, style}) => {
    const div = document.createElement('div');
    const isCur = seed === curSeed && style === curStyle;
    div.className = 'avatar-opt' + (isCur ? ' selected' : '');
    div.onclick = () => {
      document.querySelectorAll('.avatar-opt').forEach(d => d.classList.remove('selected'));
      div.classList.add('selected');
      _pickerSelected = {seed, style};
    };
    const img = document.createElement('img');
    img.src = getAvatarUrl(seed, style);
    img.alt = seed;
    div.appendChild(img);
    grid.appendChild(div);
  });

  document.getElementById('avatarModal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeAvatarPicker() {
  document.getElementById('avatarModal').classList.add('hidden');
  document.body.style.overflow = '';
}

function confirmAvatar() {
  if (!_pickerSelected) { closeAvatarPicker(); return; }
  localStorage.setItem(AVATAR_KEY, JSON.stringify(_pickerSelected));
  // Also update in user record
  if (currentUser) {
    saveUser(currentUser, { avatarSeed: _pickerSelected.seed, avatarStyle: _pickerSelected.style });
  }
  updateNavUser();
  closeAvatarPicker();
  showToast('✅ Профайл дүрс шинэчлэгдлээ!', 'success');
}


/* ════════════════════════════════════
   TRAINING SECTION
   4 бүлэг: Монгол хэл / Уран зохиол / Үндэсний бичиг / Монгол хэл+бусад
════════════════════════════════════ */
/* ── ҮНЭ ─────────────────────────────────────────────────────────
   Бүх үнийг ЗӨВХӨН ЭНД засна. Сургалтын карт, дэлгэрэнгүй цонх,
   төлбөрийн (QR) цонх — бүгд эндээс уншдаг тул зөрөхгүй.
──────────────────────────────────────────────────────────────── */
const fmtMNT = n => Number(n).toLocaleString('en-US') + '₮';
const PRICE = {
  mongolOnline: 30000,   // Монгол хэл · онлайн · 3 сарын багц
  extendMonth:  5000,    // Онлайн багцыг 1 сараар сунгах
  onsite:       200000,  // Танхимын сургалт (Монгол хэл, Үндэсний бичиг)
  deposit:      50000,   // Танхимд бүртгүүлэхэд QR-аар төлөх урьдчилгаа
  scriptOnline: 99000,   // Үндэсний бичиг · онлайн
  cashbackPct:  20,      // Үндэсний бичиг онлайн — cashback хувь
  homework:     50000    // Гэрийн даалгаврын тусламж · сар
};
PRICE.cashback  = PRICE.scriptOnline * PRICE.cashbackPct / 100; // 19,800₮
PRICE.scriptNet = PRICE.scriptOnline - PRICE.cashback;           // 79,200₮

const ONSITE_LOCATION = 'Peace Mall оффисын хаалгаар ороод 9 давхарт, 903 тоот — "Эрдмийн Гүүр" сургалтын танхим';

// total = сургалтын нийт үнэ · payNow = QR/дансаар ОДОО шилжүүлэх дүн
const COURSE_DATA = {
  mongol: {
    icon:'🗣',
    color:'#fef3c7',
    title:'Монгол хэл — Дүрэм, найруулга, бичих чадвар',
    hasMode: true,
    modes: {
      online: {
        subtitle:`${fmtMNT(PRICE.mongolOnline)} · Онлайн · 3 сар`,
        desc:'Бэлэн бичлэг хичээл, интерактив даалгавартай цахим анги. Төлсөн даруйд эхэлнэ.',
        features:[
          {icon:'🎬', text:'Бичлэг хичээл', sub:'Хүссэн үедээ үзнэ'},
          {icon:'📝', text:'Даалгавар', sub:'Хичээл бүрийн дараа'},
          {icon:'⏳', text:'3 сар хүчинтэй', sub:`+${fmtMNT(PRICE.extendMonth)}-өөр 1 сар сунгана`},
          {icon:'🔓', text:'Үргэлж нээлттэй', sub:'Хүссэн үедээ бүртгүүлнэ'},
        ],
        hasSchedule:false, hasAge:false, location:null,
        total: PRICE.mongolOnline, payNow: PRICE.mongolOnline,
        priceNote:`${fmtMNT(PRICE.mongolOnline)} — 3 сарын багц`,
        priceFull:fmtMNT(PRICE.mongolOnline),
        priceSub:'Онлайн · 3 сар хүчинтэй'
      },
      onsite: {
        subtitle:`${fmtMNT(PRICE.onsite)} · Танхим · Бямба, Ням`,
        desc:'Танхимд биечлэн хичээллэнэ. Бүртгэл сар бүрийн сүүлийн долоо хоногоос эхэлнэ (одоогийн бүртгэл 2026.09.17–09.25).',
        features:[
          {icon:'📍', text:'Танхим дээр', sub:'Биечлэн ирж суух'},
          {icon:'📅', text:'Бямба, Ням', sub:'Амралтын 2 өдөр'},
          {icon:'🕐', text:'10:00–12:00 / 13:00–15:00', sub:'2 цагийн хичээл'},
          {icon:'👤', text:'Макс 10 суралцагч', sub:'Цөөн, анхаарал хангалттай'},
        ],
        hasSchedule:false, hasAge:false,
        location:ONSITE_LOCATION,
        total: PRICE.onsite, payNow: PRICE.deposit,
        priceNote:`${fmtMNT(PRICE.onsite)} — Урьдчилгаа ${fmtMNT(PRICE.deposit)}`,
        priceFull:fmtMNT(PRICE.onsite),
        priceSub:`Урьдчилгаа ${fmtMNT(PRICE.deposit)}`
      }
    }
  },
  literature: {
    icon:'📚',
    color:'#f0fdf4',
    title:'Уран зохиолын хичээл',
    comingSoon: true,
    subtitle:'🔜 Тун удахгүй бүртгэл эхэлнэ',
    desc:'Уншсан зохиол (аудио хичээл), онолын ойлголт, даалгавартай цахим сан. 6–12-р ангийн сурах бичгийн зохиолуудыг ойлгомжтой уншсан аудио бичлэгтэй болно.',
    features:[
      {icon:'🎧', text:'Уншсан зохиол', sub:'Аудио хичээл'},
      {icon:'📖', text:'Онолын ойлголт', sub:'Уран зохиолын онол'},
      {icon:'📝', text:'Даалгавар', sub:'Ойлголтоо бататгана'},
      {icon:'🔜', text:'Тун удахгүй', sub:'Бүртгэл нээгдээгүй'},
    ],
    hasSchedule:false, hasAge:false, location:null,
    priceNote:'Тун удахгүй',
    priceFull:'Тун удахгүй',
    priceSub:'Бүртгэл нээгдээгүй'
  },
  script: {
    icon:'ᠮ',
    color:'#ede9fe',
    title:'Үндэсний бичгийн анхан шатны сургалт',
    hasMode: true,
    modes: {
      online: {
        subtitle:`${fmtMNT(PRICE.scriptOnline)} · Meet · ${PRICE.cashbackPct}% Cashback`,
        desc:'Meet уулзалтаар анхан шатны сургалт. Материалыг багш өгнө — тусад нь худалдаж авах шаардлагагүй.',
        features:[
          {icon:'🗓', text:'2026.09.17-оос', sub:'Орой 19:00'},
          {icon:'💻', text:'Meet уулзалт', sub:'Онлайн бүлгийн хичээл'},
          {icon:'📄', text:'Материал багшаас', sub:'Тусгай зардалгүй'},
          {icon:'👤', text:'Макс 10 суралцагч', sub:'Цөөн, анхаарал хангалттай'},
        ],
        hasSchedule:false, hasAge:false, location:null,
        total: PRICE.scriptOnline, payNow: PRICE.scriptOnline,
        payNote:`Нөхцөл биелвэл ${fmtMNT(PRICE.cashback)} буцаагдана`,
        priceNote:`${fmtMNT(PRICE.scriptOnline)} — Cashback-тэй бол ${fmtMNT(PRICE.scriptNet)}`,
        priceFull:fmtMNT(PRICE.scriptOnline),
        priceSub:`Cashback-тэй бол ${fmtMNT(PRICE.scriptNet)}`
      },
      onsite: {
        subtitle:`${fmtMNT(PRICE.onsite)} · Танхим · Бямба, Ням`,
        desc:'Танхимд биечлэн хичээллэнэ. Бүртгэл сар бүрийн сүүлийн долоо хоногоос эхэлнэ.',
        features:[
          {icon:'📍', text:'Танхим дээр', sub:'Биечлэн ирж суух'},
          {icon:'📅', text:'Бямба, Ням', sub:'Амралтын 2 өдөр'},
          {icon:'🕐', text:'2 цагийн хичээл', sub:'Цагийг багшаас лавлана'},
          {icon:'👤', text:'Макс 10 суралцагч', sub:'Цөөн, анхаарал хангалттай'},
        ],
        hasSchedule:false, hasAge:false,
        location:ONSITE_LOCATION,
        total: PRICE.onsite, payNow: PRICE.deposit,
        priceNote:`${fmtMNT(PRICE.onsite)} — Урьдчилгаа ${fmtMNT(PRICE.deposit)}`,
        priceFull:fmtMNT(PRICE.onsite),
        priceSub:`Урьдчилгаа ${fmtMNT(PRICE.deposit)}`
      }
    }
  },
  other: {
    icon:'📝',
    color:'#fdf4ff',
    title:'Монгол хэл + бусад хичээлийн гэрийн даалгаврын тусламж',
    subtitle:`${fmtMNT(PRICE.homework)} / сар · Ганцаарчилсан Meet · Цагт 2 сурагч`,
    desc:'Онлайн ганцаарчилсан Meet. Даваа–Баасан хичээллэнэ, Бямба·Нямд бүртгэл авна. Цагаа сонгоод бүртгүүлнэ — багш зөвшөөрвөл баталгаажна.',
    features:[
      {icon:'💻', text:'Онлайн Meet', sub:'Ганцаарчилсан хичээл'},
      {icon:'📅', text:'Даваа–Баасан', sub:'Хичээлийн өдрүүд'},
      {icon:'✏️', text:'Бямба·Нямд бүртгэл', sub:'Долоо хоног бүр нээнэ'},
      {icon:'👤', text:'Цагт 2 сурагч', sub:'Дүүрсэн бол хаагдана'},
    ],
    hasSchedule: true,
    hasAge: false,
    total: PRICE.homework, payNow: PRICE.homework,
    priceNote:`${fmtMNT(PRICE.homework)} — Анхны хямдаралтай үнэ / сар`,
    priceFull:fmtMNT(PRICE.homework),
    priceSub:'Сар · анхны хямдрал'
  }
};

/* ── Тухайн сургалтын (горимын) үнийн мэдээлэл — карт, modal, төлбөр нэг эх сурвалжтай ── */
function getCourseInfo(type) {
  const raw  = COURSE_DATA[type] || {};
  const mode = courseMode[type] || 'online';
  const d    = raw.hasMode ? {...raw, ...raw.modes[mode]} : raw;
  const modeLabel = raw.hasMode ? (mode === 'onsite' ? 'Танхим' : 'Онлайн') : '';
  const total  = d.total || 0;
  const payNow = d.payNow != null ? d.payNow : total;
  return { d, modeLabel, total, payNow, isDeposit: payNow < total };
}

/* ── Course mode toggle (Онлайн / Танхим) ── */
const courseMode = { mongol:'online', script:'online' };

/* ── Картуудын анхны үнийг data-аас тавина (HTML-тэй зөрөхгүй) ── */
function initCoursePrices() {
  const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
  ['mongol','script'].forEach(t => {
    const m = COURSE_DATA[t].modes[courseMode[t]];
    set(`${t}-price`, m.priceFull);
    set(`${t}-priceSub`, m.priceSub);
  });
  set('hw-price',    COURSE_DATA.other.priceFull);
  set('hw-priceSub', COURSE_DATA.other.priceSub);
  set('scriptCashbackNote', `🎁 ${PRICE.cashbackPct}% cashback — ${fmtMNT(PRICE.cashback)} буцаагдана`);
  set('scriptRibbon', `${PRICE.cashbackPct}% CASHBACK`);
}
initCoursePrices();


function setCourseMode(type, mode, btnEl) {
  courseMode[type] = mode;
  const card = btnEl.closest('.course-card');
  if (!card) return;

  card.querySelectorAll('.mode-btn').forEach(b=>b.classList.remove('active'));
  btnEl.classList.add('active');

  card.querySelectorAll('.mode-block').forEach(b=>{
    b.classList.toggle('active', b.dataset.modeBlock === mode);
  });

  const d = COURSE_DATA[type];
  const m = d && d.modes ? d.modes[mode] : null;
  if (m) {
    const priceEl = document.getElementById(`${type}-price`);
    const subEl   = document.getElementById(`${type}-priceSub`);
    if (priceEl) priceEl.textContent = m.priceFull || m.priceNote;
    if (subEl)   subEl.textContent   = m.priceSub || '';
  }

  // Cashback ribbon only makes sense for the online Script class
  const ribbon = document.getElementById('scriptRibbon');
  if (ribbon && type === 'script') ribbon.style.display = (mode === 'online') ? '' : 'none';
}

function filterTraining(cat, btn) {
  document.querySelectorAll('.tr-flt-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.course-card').forEach(card=>{
    if(cat==='all'||card.dataset.cat===cat){card.style.display='';}
    else{card.style.display='none';}
  });
}

function openCourseDetail(type) {
  _currentCourseType = type;
  const raw = COURSE_DATA[type];
  if(!raw) return;
  const { d } = getCourseInfo(type);

  document.getElementById('cmHeaderContent').innerHTML = `
    <div style="display:flex;align-items:center;gap:14px">
      <div style="width:56px;height:56px;border-radius:16px;background:${d.color};display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0">${d.icon}</div>
      <div>
        <div style="font-size:18px;font-weight:800;color:#fff;font-family:'Montserrat',sans-serif;line-height:1.2">${d.title}</div>
        <div style="font-size:14px;color:rgba(255,255,255,.65);margin-top:4px">${d.subtitle}</div>
      </div>
    </div>`;

  const ageSection = d.hasAge ? `
    <div style="margin-bottom:20px">
      <div style="font-size:14px;font-weight:800;margin-bottom:10px">👶 Насны бүлэг — ангилалт бүрт 3 суралцагч</div>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px">
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:10px;text-align:center"><div style="font-size:14px;font-weight:800;color:#1d4ed8">6–9 нас</div></div>
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:10px;text-align:center"><div style="font-size:14px;font-weight:800;color:#1d4ed8">10–13 нас</div></div>
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:10px;text-align:center"><div style="font-size:14px;font-weight:800;color:#1d4ed8">14–17 нас</div></div>
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:10px;text-align:center"><div style="font-size:14px;font-weight:800;color:#1d4ed8">18+ нас</div></div>
      </div>
    </div>` : '';

  const locationSection = d.location ? `<div class="cm-loc">📍 ${d.location}</div>` : '';

  const cashbackSection = (type==='script' && courseMode.script==='online') ? `
    <div class="cm-note">
      <strong>🎁 ${PRICE.cashbackPct}% cashback — ${fmtMNT(PRICE.cashback)} буцаагдана</strong>
      <span>Нөхцөл: нэг ч өдөр тасалдалгүй даалгавраа бүрэн хийх · хичээлийн үед дүрсээ асааж ярих</span>
    </div>` : '';

  const schedSection = (type==='other') ? `
    <div class="course-time-row" style="margin-bottom:16px">
      <span class="lbl">🕐 Цаг:</span>
      <span class="time-pill">19:00</span><span class="time-pill">20:00</span><span class="time-pill">21:00</span>
    </div>` : '';

  const enrollSection = raw.comingSoon
    ? `<div style="background:var(--surface2);border-radius:14px;padding:16px;text-align:center;font-size:15px;color:var(--muted);font-weight:800;margin-bottom:8px">🔜 Тун удахгүй бүртгэл эхэлнэ</div>`
    : `<button onclick="closeCourseModal();openCoursePayModal('${type}')" class="btn-p" style="width:100%;padding:14px;font-size:15px;border-radius:14px;font-weight:800">🎓 Одоо бүртгүүлэх →</button>`;

  document.getElementById('cmBody').innerHTML = `
    <p style="font-size:15px;color:var(--mid);line-height:1.7;margin-bottom:18px">${d.desc}</p>
    <div class="cm-features">
      ${d.features.map(f=>`<div class="cm-feature"><div class="cf-icon">${f.icon}</div><div><div class="cf-text">${f.text}</div><div class="cf-sub">${f.sub}</div></div></div>`).join('')}
    </div>
    ${ageSection}
    ${locationSection}
    ${cashbackSection}
    ${schedSection}
    <div class="cm-price">
      <div>
        <div class="cm-price-lbl">Үнэ</div>
        <div class="cm-price-amt">${d.priceFull||d.priceNote}</div>
        <div class="cm-price-sub">${d.priceSub||''}</div>
      </div>
      <div style="font-size:32px">💳</div>
    </div>
    ${enrollSection}
    <button onclick="closeCourseModal()" style="width:100%;padding:10px;margin-top:8px;background:none;border:none;font-size:14px;color:#aaa;cursor:pointer;font-family:'Manrope',sans-serif">Хаах</button>`;

  document.getElementById('courseModal').classList.remove('hidden');
}

function closeCourseModal() {
  document.getElementById('courseModal').classList.add('hidden');
}

/* ── COURSE ENROLL PAY MODAL ── */
function openCoursePayModal(type) {
  _currentCourseType = type;
  const raw = COURSE_DATA[type];
  if(!raw || raw.comingSoon) return;
  const { d, modeLabel, total, payNow, isDeposit } = getCourseInfo(type);

  document.getElementById('cpTitle').textContent = d.title + (modeLabel ? ` (${modeLabel})` : '');
  document.getElementById('cpSubtitle').textContent = 'QR уншуулж эсвэл данс руу шилжүүлнэ үү';

  // QR/дансаар ОДОО шилжүүлэх дүн: урьдчилгаатай бол урьдчилгаа, бусад үед бүтэн үнэ
  document.getElementById('cpAmtLbl').textContent = isDeposit ? 'Одоо төлөх урьдчилгаа' : 'Төлөх дүн';
  document.getElementById('cpAmt').textContent    = fmtMNT(payNow);
  document.getElementById('cpAmtSub').textContent = isDeposit
    ? `Нийт ${fmtMNT(total)} · үлдэгдэл ${fmtMNT(total - payNow)}-ийг ирэхдээ багшид өгнө`
    : (d.payNote || '');

  const noteEl = document.getElementById('cpNote');
  if (noteEl) noteEl.innerHTML = 'Гүйлгээний утга: <strong>и-мэйл · Сургалтын нэр' + (type==='other' ? ' · Цаг' : '') + '</strong>';

  // Show/hide schedule picker
  const sw = document.getElementById('cpSchedWrap');
  if(sw) sw.style.display = d.hasSchedule ? 'block' : 'none';
  // Show/hide time slot picker (Монгол хэл + бусад хичээл only)
  const tw = document.getElementById('cpTimeWrap');
  if(tw) tw.style.display = (type==='other') ? 'block' : 'none';
  // Reset time slot / schedule selections
  document.querySelectorAll('.cp-time-btn').forEach(b=>{
    b.classList.remove('active');
    b.style.borderColor=''; b.style.background=''; b.style.color='';
  });
  document.querySelectorAll('.sched-sel-btn').forEach(b=>b.classList.remove('active'));

  cpGoStep1();
  document.getElementById('coursePayModal').classList.remove('hidden');
}

function closeCoursePayModal() {
  document.getElementById('coursePayModal').classList.add('hidden');
  cpGoStep1();
}

function cpGoStep1(){document.getElementById('cpStep1').style.display='';document.getElementById('cpStep3').style.display='none';}
function cpGoDone(){document.getElementById('cpStep1').style.display='none';document.getElementById('cpStep3').style.display='';}

function toggleSchedBtn(btn){btn.classList.toggle('active');}

function selectTimeSlot(btn) {
  // Only one time slot at a time
  document.querySelectorAll('.cp-time-btn').forEach(b=>{
    b.classList.remove('active');
    b.style.borderColor='var(--border)';
    b.style.background='#fff';
    b.style.color='var(--mid)';
  });
  btn.classList.add('active');
  btn.style.borderColor='var(--amber)';
  btn.style.background='var(--amber-l)';
  btn.style.color='var(--amber-d)';
}

async function cpConfirmPaid() {
  const schedDays = [...document.querySelectorAll('.sched-sel-btn.active')].map(b=>b.textContent).join(', ');
  const timeSlot  = [...document.querySelectorAll('.cp-time-btn.active')].map(b=>b.dataset.time).join(', ') || '';
  const { d, modeLabel, total, payNow, isDeposit } = getCourseInfo(_currentCourseType);
  const label = d.title + (modeLabel ? ` (${modeLabel})` : '');

  // Монгол хэл + бусад хичээл — цаг сонгохгүй бол баталгаажуулахгүй
  const tw = document.getElementById('cpTimeWrap');
  if (tw && tw.style.display !== 'none' && !timeSlot) {
    showToast('Хичээллэх цагаа сонгоно уу', 'error');
    return;
  }

  const email = currentUser !== 'guest@shb.mn' ? currentUser : '';
  const btn = document.getElementById('cpSubmitBtn');
  btn.disabled=true;btn.textContent='⏳ Илгээж байна...';

  try {
    await fetch(GAS_URL,{method:'POST',mode:'no-cors',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        action:'submitOrder',
        email,
        note:`Сургалт: ${label} | Хуваарь: ${schedDays} | Цаг: ${timeSlot}`,
        // total = QR/дансаар яг шилжүүлсэн дүн (урьдчилгаатай бол урьдчилгаа)
        total: payNow,
        items:`Сургалтын бүртгэл: ${label} — төлсөн ${fmtMNT(payNow)}` + (isDeposit ? ` (урьдчилгаа, нийт ${fmtMNT(total)})` : ''),
        date:new Date().toLocaleString('mn-MN')
      })
    });
    cpGoDone();
    showToast('Баталгаажлаа!','success');
  } catch(e) {
    showToast('Сүлжээний алдаа. Дахин оролдоно уу.','error');
  } finally {
    btn.disabled=false;btn.textContent='✅ Төлбөрөө хийлээ';
  }
}

/* ════════════════════════════════════
   PRODUCTS / SHOP
════════════════════════════════════ */
function parseGvizJson(raw){return JSON.parse(raw.replace(/^[^(]+\(/,'').replace(/\);?\s*$/,''));}
async function loadProducts(){
  ['shopGrid','dashGrid'].forEach(id=>{const g=document.getElementById(id);if(g)g.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:44px;color:#bbb"><div style="width:32px;height:32px;border:3px solid var(--border);border-top-color:var(--amber);border-radius:50%;animation:spin .8s linear infinite;margin:0 auto 12px"></div><p style="font-size:12px;font-weight:600">Ачааллаж байна...</p></div>`;});
  try{
    const url=`https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent(SHEET_NAME)}`;
    const resp=await fetch(url);if(!resp.ok)throw new Error();
    const gviz=parseGvizJson(await resp.text());
    const cols=gviz.table.cols,rows=gviz.table.rows;
    function findCol(...names){const lc=names.map(n=>n.toLowerCase().trim());for(let i=0;i<cols.length;i++){const l=(cols[i].label||cols[i].id||'').toLowerCase().trim();if(lc.some(n=>l.includes(n)||n.includes(l)))return i;}return -1;}
    const CI={title:Math.max(0,findCol('title','гарчиг','нэр')),desc:Math.max(1,findCol('description','тайлбар')),price:Math.max(2,findCol('price','үнэ','дүн')),img:Math.max(3,findCol('images','зураг','image')),type:Math.max(4,findCol('type','төрөл')),link:Math.max(5,findCol('link','холбоос','url'))};
    const safeVal=c=>!c?'':String(c.f!=null?c.f:(c.v??'')).trim();
    const safeNum=c=>(!c||c.v==null)?0:Number(c.v)||0;
    allProducts=rows.filter(r=>r.c&&r.c[CI.title]&&(r.c[CI.title].v||r.c[CI.title].f)).map((r,i)=>{
      const c=r.c,type=safeVal(c[CI.type]),price=safeNum(c[CI.price]),free=price===0||['free','free-sample'].includes(type.toLowerCase());
      return{id:i+1,title:safeVal(c[CI.title]),desc:safeVal(c[CI.desc]),price,type,cat:free?'Үнэгүй':'Төлбөртэй',icon:free?'🎁':'📝',link:safeVal(c[CI.link]),img:safeVal(c[CI.img])};
    });
    renderProducts(allProducts,'shopGrid');renderProducts(allProducts.slice(-5).reverse(),'dashGrid');
  }catch(e){
    const err=`<div style="grid-column:1/-1;text-align:center;padding:44px;color:#bbb"><p style="font-size:12px;font-weight:600;margin-bottom:8px">⚠️ Бүтээгдэхүүн ачаалах боломжгүй.</p><button class="btn-p" style="margin-top:14px;font-size:11px" onclick="loadProducts()">🔄 Дахин</button></div>`;
    ['shopGrid','dashGrid'].forEach(id=>{const g=document.getElementById(id);if(g)g.innerHTML=err;});
  }
}
function isFreeP(p){return p.price===0||['free','free-sample'].includes((p.type||'').toLowerCase().trim());}
function driveDownloadUrl(link){if(!link)return'';const m1=link.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);if(m1)return`https://drive.google.com/uc?export=download&id=${m1[1]}`;const m2=link.match(/[?&]id=([a-zA-Z0-9_-]+)/);if(m2)return`https://drive.google.com/uc?export=download&id=${m2[1]}`;return link;}
function productImgHTML(p){if(p.img){const fn=p.img.split(',')[0].trim();if(fn){const url=`https://raw.githubusercontent.com/tuult764-crypto/sonirholtoi-hel-bichig-/main/${encodeURIComponent(fn)}`;return`<img src="${url}" alt="${p.title}" style="width:100%;height:100%;object-fit:cover;display:block" onerror="this.style.display='none';this.nextSibling.style.display='flex'"><span style="display:none;font-size:44px;width:100%;height:100%;align-items:center;justify-content:center">${p.icon}</span>`;}}return`<span style="font-size:44px">${p.icon}</span>`;}
function renderProducts(prods,gridId){
  const grid=document.getElementById(gridId);if(!grid)return;
  if(!prods.length){grid.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:44px;color:#bbb"><p style="font-size:12px;font-weight:600">Бүтээгдэхүүн олдсонгүй</p></div>`;return;}
  grid.innerHTML=prods.map(p=>{
    const free=isFreeP(p),dlUrl=driveDownloadUrl(p.link);
    const actionBtn=free?(dlUrl?`<a href="${dlUrl}" target="_blank" rel="noopener" style="display:flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:9px;background:#d1fae5;color:#065f46;font-size:14px;text-decoration:none;flex-shrink:0" download>⬇</a>`:''):`<button class="add-cart" onclick="openPreview(allProducts.find(x=>x.id===${p.id}))" title="Жишээ" style="font-size:13px">👁</button><button class="add-cart" onclick="addToCart(${p.id})">🛒</button>`;
    const badgeStyle=free?'background:#d1fae5;color:#065f46':'background:rgba(255,255,255,.92);color:var(--dark)';
    const cardBorder=free?'border:2px solid #a7f3d0':'border:1px solid var(--border)';
    return`<div class="prod-card" style="${cardBorder}">
      <div class="prod-img" style="overflow:hidden;position:relative">${productImgHTML(p)}<span class="prod-badge" style="${badgeStyle}">${free?'🎁 Үнэгүй':p.cat}</span></div>
      <div class="prod-body">
        <div class="prod-title" title="${p.desc||p.title}">${p.title}</div>
        ${p.desc?`<div style="font-size:10px;color:var(--mid);margin-bottom:10px;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${p.desc}</div>`:''}
        <div class="prod-foot">
          <span class="prod-price" style="${free?'color:#065f46':''}">${free?'🆓 ҮНЭГҮЙ':p.price.toLocaleString()+'₮'}</span>
          <div style="display:flex;gap:5px;align-items:center">${actionBtn}</div>
        </div>
        ${free&&dlUrl?`<a href="${dlUrl}" target="_blank" rel="noopener" download style="display:block;margin-top:9px;text-align:center;background:var(--green);color:#fff;padding:8px;border-radius:11px;font-size:11px;font-weight:700;text-decoration:none">⬇ Татаж авах</a>`:''}
      </div></div>`;
  }).join('');
}
function filterShop(cat,btn){document.querySelectorAll('.flt-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const f=cat==='all'?allProducts:allProducts.filter(p=>p.cat===cat);renderProducts(f,'shopGrid');}
function openPreview(p){
  if(!p)return;const imgs=(p.img||'').split(',').map(s=>s.trim()).filter(Boolean);
  if(!imgs.length){showToast('Жишээ зураг байхгүй','error');return;}
  const slides=imgs.map((name,i)=>{const url=`https://raw.githubusercontent.com/tuult764-crypto/sonirholtoi-hel-bichig-/main/${encodeURIComponent(name)}`;return`<div class="preview-slide" style="display:${i===0?'flex':'none'};align-items:center;justify-content:center;width:100%;height:100%"><img src="${url}" alt="${name}" style="max-width:100%;max-height:100%;object-fit:contain;border-radius:10px"></div>`;}).join('');
  const dots=imgs.length>1?`<div style="display:flex;gap:5px;justify-content:center;margin-top:10px">${imgs.map((_,i)=>`<button onclick="previewGoTo(${i})" id="pdot${i}" style="width:7px;height:7px;border-radius:50%;border:none;cursor:pointer;background:${i===0?'var(--amber)':'#ddd'};padding:0;transition:all .2s"></button>`).join('')}</div>`:'';
  const nav=imgs.length>1?`<button onclick="previewNav(-1)" style="position:absolute;left:7px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.4);color:#fff;border:none;border-radius:50%;width:34px;height:34px;font-size:17px;cursor:pointer;z-index:2">‹</button><button onclick="previewNav(1)" style="position:absolute;right:7px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.4);color:#fff;border:none;border-radius:50%;width:34px;height:34px;font-size:17px;cursor:pointer;z-index:2">›</button>`:'';
  document.getElementById('previewModalBody').innerHTML=`
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px">
      <div><div style="font-size:15px;font-weight:800">${p.title}</div><div style="font-size:11px;color:var(--mid);margin-top:3px">${p.desc||''}</div></div>
      <button onclick="closePreviewModal()" style="background:#f5f5f5;border:none;border-radius:50%;width:30px;height:30px;font-size:14px;cursor:pointer;flex-shrink:0;margin-left:10px">✕</button>
    </div>
    <div style="position:relative;background:#f5ede0;border-radius:14px;height:380px;overflow:hidden;display:flex;align-items:center;justify-content:center">
      <div id="previewSlides" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center">${slides}</div>${nav}</div>
    ${dots}
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px">
      <div style="font-size:17px;font-weight:800;color:var(--amber)">${p.price.toLocaleString()}₮</div>
      <button onclick="closePreviewModal();addToCart(${p.id})" class="btn-p" style="padding:9px 22px">🛒 Сагсанд нэмэх</button>
    </div>`;
  window._previewIdx=0;window._previewTotal=imgs.length;
  document.getElementById('previewModal').classList.remove('hidden');
}
function previewNav(dir){const t=window._previewTotal||0;if(t<=1)return;const slides=document.querySelectorAll('.preview-slide'),dots=document.querySelectorAll('[id^="pdot"]');slides[window._previewIdx].style.display='none';if(dots[window._previewIdx])dots[window._previewIdx].style.background='#ddd';window._previewIdx=(window._previewIdx+dir+t)%t;slides[window._previewIdx].style.display='flex';if(dots[window._previewIdx])dots[window._previewIdx].style.background='var(--amber)';}
function previewGoTo(idx){const slides=document.querySelectorAll('.preview-slide'),dots=document.querySelectorAll('[id^="pdot"]');slides[window._previewIdx].style.display='none';if(dots[window._previewIdx])dots[window._previewIdx].style.background='#ddd';window._previewIdx=idx;slides[window._previewIdx].style.display='flex';if(dots[window._previewIdx])dots[window._previewIdx].style.background='var(--amber)';}
function closePreviewModal(){document.getElementById('previewModal').classList.add('hidden');}

/* ── CART & PAY ── */
function addToCart(id){const p=allProducts.find(x=>x.id===id);if(!p)return;if(isFreeP(p)){const dl=driveDownloadUrl(p.link);if(dl)window.open(dl,'_blank','noopener');else showToast('Татах холбоос байхгүй','error');return;}if(cartItems.find(x=>x.id===id)){showToast('Аль хэдийн сагсанд байна','error');return;}cartItems.push(p);document.getElementById('cartBadge').textContent=cartItems.length;showToast(`"${p.title}" сагсанд нэмэгдлээ`,'success');}
function openCart(){if(!cartItems.length){showToast('Сагс хоосон байна','error');return;}const total=cartItems.reduce((s,p)=>s+p.price,0);document.getElementById('payAmount').textContent=total.toLocaleString()+'₮';document.getElementById('payItemList').innerHTML=cartItems.map(p=>`• ${p.title} — ${p.price===0?'Үнэгүй':p.price.toLocaleString()+'₮'}`).join('<br>');document.getElementById('payEmail').value=currentUser;goToStep1();document.getElementById('payModal').classList.remove('hidden');}
function goToStep1(){['payStep1','payStep2','payStep3'].forEach((id,i)=>document.getElementById(id).style.display=i===0?'':'none');}
function goToStep2(){['payStep1','payStep2','payStep3'].forEach((id,i)=>document.getElementById(id).style.display=i===1?'':'none');}
function closePayment(){document.getElementById('payModal').classList.add('hidden');goToStep1();}
async function submitOrder(){
  const email=document.getElementById('payEmail').value.trim(),note=document.getElementById('payNote').value.trim();
  if(!email||!email.includes('@')){showToast('Зөв и-мэйл хаяг оруулна уу','error');return;}
  const btn=document.getElementById('submitOrderBtn');btn.disabled=true;btn.textContent='⏳ Илгээж байна...';
  const total=cartItems.reduce((s,p)=>s+p.price,0);
  try{await fetch(GAS_URL,{method:'POST',mode:'no-cors',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'submitOrder',email,note,total,items:cartItems.map(p=>p.title).join(', '),itemLinks:cartItems.map(p=>p.link||'').join(', '),date:new Date().toLocaleString('mn-MN')})});
    document.getElementById('confirmEmail').textContent=email;
    ['payStep1','payStep2','payStep3'].forEach((id,i)=>document.getElementById(id).style.display=i===2?'':'none');
    cartItems=[];document.getElementById('cartBadge').textContent='0';
  }catch(e){showToast('Сүлжээний алдаа. Дахин оролдоно уу.','error');}
  btn.disabled=false;btn.textContent='🚀 Захиалга илгээх';
}

/* ── LIBRARY ── */
async function loadLibrary(){
  const grid=document.getElementById('libraryGrid'),status=document.getElementById('libStatus');
  grid.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:44px"><div style="width:32px;height:32px;border:3px solid var(--border);border-top-color:var(--amber);border-radius:50%;animation:spin .8s linear infinite;margin:0 auto 12px"></div><p style="font-size:12px;font-weight:600;color:#bbb">Шалгаж байна...</p></div>`;
  status.style.display='none';
  try{
    const resp=await fetch(GAS_URL+'?action=getApproved&email='+encodeURIComponent(currentUser));
    const data=await resp.json();
    if(!data||!data.length){grid.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:56px;color:#bbb"><div style="font-size:44px;margin-bottom:12px">📭</div><p style="font-size:13px;font-weight:600">Баталгаажсан захиалга байхгүй байна.</p><button class="btn-p" style="margin-top:18px" onclick="showSec('shop')">Сургалтын материалт очих</button></div>`;return;}
    status.style.display='block';status.textContent=`✅ ${data.length} файл таны санд байна`;
    grid.innerHTML=data.map(item=>`<div class="prod-card" style="border:2px solid #d1fae5"><div class="prod-img" style="background:#f0fdf4"><span style="font-size:44px">📄</span><span class="prod-badge" style="background:#d1fae5;color:#065f46">Баталгаажсан</span></div><div class="prod-body"><div class="prod-title">${item.title}</div><div style="font-size:10px;color:#999;margin-bottom:10px">📅 ${item.date}</div><a href="${item.link}" target="_blank" rel="noopener" style="display:block;text-align:center;background:var(--green);color:#fff;padding:9px;border-radius:11px;font-size:12px;font-weight:700;text-decoration:none">⬇ Татаж авах</a></div></div>`).join('');
  }catch(e){grid.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:56px;color:#bbb"><p style="font-size:12px;font-weight:600">Мэдээлэл татахад алдаа гарлаа.</p></div>`;}
}

/* ════════════════════════════════════
   TOAST
════════════════════════════════════ */
let toastTimer;
function showToast(msg,type='success'){const t=document.getElementById('toast');t.textContent=msg;t.className='show '+type;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{t.className='';},3000);}

/* ════════════════════════════════════
   SUDOKU
════════════════════════════════════ */
/* Судоку хэвлэх: өдөрт 1 хуудас (4 судоку) үнэгүй. Тэмдэглэгээг энэ төхөөрөмж дээр (Улаанбаатарын өдрөөр) хадгална. */
const DAILY_PRINT_KEY='shb_sudoku_print_day';
function todayUB(){try{return new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'});}catch(e){return new Date().toISOString().slice(0,10);}}
function printedToday(){try{return localStorage.getItem(DAILY_PRINT_KEY)===todayUB();}catch(e){return false;}}
function updatePrintUI(){
  const el=document.getElementById('printStatus');if(!el)return;
  const used=printedToday();
  el.textContent=used?'✔ Өнөөдрийн үнэгүй хэвлэлт ашиглагдсан':'🖨 Өнөөдөр 1 хуудас үнэгүй хэвлэнэ';
  el.classList.toggle('used',used);
}

function initSudoku(){
  const{puzzle,solution}=generateSudoku();sudokuSolution=solution;sudokuPuzzle=puzzle;
  const grid=document.getElementById('sudokuGrid');if(!grid)return;grid.innerHTML='';
  for(let row=0;row<9;row++){for(let col=0;col<9;col++){
    const idx=row*9+col,val=puzzle[idx],inp=document.createElement('input');
    inp.type='text';inp.maxLength=1;inp.className='sudoku-cell';
    if(col===2||col===5)inp.classList.add('border-r');if(row===2||row===5)inp.classList.add('border-b');
    if(val){inp.value=MONG_NUMS[String(val)]||'';inp.readOnly=true;inp.classList.add('readonly');}
    inp.addEventListener('input',function(e){const ch=e.target.value.slice(-1);if(MONG_NUMS[ch])this.value=MONG_NUMS[ch];else if(Object.values(MONG_NUMS).includes(ch))this.value=ch;else this.value='';this.classList.remove('error');});
    inp.addEventListener('keydown',function(e){if(e.key>='1'&&e.key<='9'){e.preventDefault();this.value=MONG_NUMS[e.key];this.classList.remove('error');}if(e.key==='Backspace'||e.key==='Delete'){this.value='';this.classList.remove('error');}});
    grid.appendChild(inp);
  }}
}
function generateSudoku(){const base=Array(81).fill(0);fillSudoku(base);const solution=[...base],puzzle=[...solution];const pos=[...Array(81).keys()].sort(()=>Math.random()-.5);let rem=0;for(const p of pos){if(rem>=45)break;puzzle[p]=0;rem++;}return{puzzle,solution};}
function generateNewPuzzle(){const base=Array(81).fill(0);fillSudoku(base);const sol=[...base],puz=[...sol];const pos=[...Array(81).keys()].sort(()=>Math.random()-.5);let rem=0;for(const p of pos){if(rem>=46)break;puz[p]=0;rem++;}return{puzzle:puz,solution:sol};}
function fillSudoku(board){const empty=board.indexOf(0);if(empty===-1)return true;const nums=shuffle([1,2,3,4,5,6,7,8,9]);for(const n of nums){if(isValidPlacement(board,empty,n)){board[empty]=n;if(fillSudoku(board))return true;board[empty]=0;}}return false;}
function isValidPlacement(board,idx,num){const row=Math.floor(idx/9),col=idx%9;for(let i=0;i<9;i++){if(board[row*9+i]===num||board[i*9+col]===num)return false;}const br=Math.floor(row/3)*3,bc=Math.floor(col/3)*3;for(let r=0;r<3;r++)for(let c=0;c<3;c++)if(board[(br+r)*9+(bc+c)]===num)return false;return true;}
function shuffle(arr){for(let i=arr.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]];}return arr;}
function checkSudoku(){const cells=document.querySelectorAll('.sudoku-cell');let hasError=false,hasEmpty=false;cells.forEach((cell,idx)=>{if(cell.readOnly)return;cell.classList.remove('error');const mv=cell.value;if(!mv){hasEmpty=true;return;}const n=parseInt(MONG_REV[mv]||mv);if(n!==sudokuSolution[idx]){cell.classList.add('error');hasError=true;}});if(hasEmpty)showToast('Бүх нүдийг бөглөнө үү','error');else if(hasError)showToast('Буруу нүд бий. Улаанаар тэмдэглэгдлээ','error');else{showToast('Маш сайн! Судоку зөв боллоо! 🎉','success');if(window.HomeProgress)HomeProgress.sudokuSolved(sudokuSolution.join(''));}}
function solveSudoku(){const cells=document.querySelectorAll('.sudoku-cell');cells.forEach((cell,idx)=>{if(!cell.readOnly){cell.value=MONG_NUMS[String(sudokuSolution[idx])]||'';cell.classList.remove('error');}});showToast('Шийдэл харуулагдлаа','success');}
function handlePrint(){
  if(printedToday()){showToast('Өнөөдрийн үнэгүй хэвлэх эрх ашиглагдсан. Маргааш дахин хэвлэнэ үү.','error');updatePrintUI();return;}
  try{localStorage.setItem(DAILY_PRINT_KEY,todayUB());}catch(e){}
  updatePrintUI();doPrint(1);
}
function printFree(){handlePrint();}
function doPrint(pageCount){
  const pages=[];for(let p=0;p<pageCount;p++){const puzzles=[];for(let q=0;q<4;q++)puzzles.push(generateNewPuzzle());pages.push(puzzles);}
  const html=buildPrintHTML(pages);showToast(`${pageCount} хуудас хэвлэж байна...`,'success');
  setTimeout(()=>{const pa=document.getElementById('printArea');if(!pa)return;pa.innerHTML=html;pa.style.display='block';
  setTimeout(()=>{window.print();function cleanup(){const el=document.getElementById('printArea');if(el){el.style.display='none';el.innerHTML='';}window.removeEventListener('afterprint',cleanup);}window.addEventListener('afterprint',cleanup);setTimeout(()=>{const el=document.getElementById('printArea');if(el&&el.style.display!=='none'){el.style.display='none';el.innerHTML='';}},4000);},400);},150);
}
function buildPrintHTML(pages){
  const MN={'1':'᠑','2':'᠒','3':'᠓','4':'᠔','5':'᠕','6':'᠖','7':'᠗','8':'᠘','9':'᠙'};
  return pages.map((puzzles,pi)=>{
    const header=`<div class="pg-hdr"><img src="https://raw.githubusercontent.com/tuult764-crypto/sonirholtoi-hel-bichig-/main/logo.png" alt="" onerror="this.style.display='none'" style="width:24px;height:24px;object-fit:contain;border-radius:5px;background:#1c1917;"><div><div class="pg-hdr-t">Сонирхолтой хэл бичиг</div><div class="pg-hdr-s">Судоку · Хуудас ${pi+1}</div></div></div>`;
    const puzzleHTMLs=puzzles.map((p,qi)=>{let rows='';for(let r=0;r<9;r++){rows+='<tr>';for(let c=0;c<9;c++){const idx=r*9+c,val=p.puzzle[idx];let cls='';if(c===2||c===5)cls+=' br';if(r===2||r===5)cls+=' bb';if(val!==0)cls+=' gv';rows+=`<td class="${cls.trim()}">${val?(MN[String(val)]||val):''}</td>`;}rows+='</tr>';}return`<div class="pp"><div class="pp-t">Судоку ${pi*4+qi+1} &nbsp;·&nbsp; Нэр:_______________ &nbsp;·&nbsp; Анги:_____</div><table class="pt"><tbody>${rows}</tbody></table><div class="pp-g">᠑=1 ᠒=2 ᠓=3 ᠔=4 ᠕=5 ᠖=6 ᠗=7 ᠘=8 ᠙=9</div></div>`;}).join('');
    return`<div class="pg">${header}${puzzleHTMLs}</div>`;
  }).join('');
}
/* ════════════════════════════════════
   ҮНДЭСНИЙ БИЧГИЙН СУРГАЛТ
   Countdown + Бүртгэлийн цонхны систем
════════════════════════════════════ */

// ── Тохируулга ──────────────────────
// Анги эхлэх цаг (Монгол цаг UTC+8)
const CLASS_START = new Date('2026-09-17T19:00:00+08:00');

// Бүртгэлийн цонх: сар бүрийн хагас сайн 00:00 → бүтэн сайн 00:00
// Монгол цаг дээр тооцоолно (UTC+8)
function getMonthlyRegWindow(now) {
  const mn = new Date(now.toLocaleString('en-US', {timeZone:'Asia/Ulaanbaatar'}));
  const y = mn.getFullYear(), m = mn.getMonth();

  // Тухайн сарын хагас сайн (Saturday) болон бүтэн сайн (Sunday) олно
  // Эхний Saturday, Sunday олно
function firstWeekend(year, month) {
  let sat = null;
  for (let d = 1; d <= 31; d++) {
    const dt = new Date(year, month, d);
    if (dt.getMonth() !== month) break;
    const dow = dt.getDay();
    if (dow === 6 && sat === null) { sat = d; continue; }
    if (dow === 0 && sat !== null) { return [{ day: 6, date: sat }, { day: 0, date: d }]; }
  }
  return [];
}

  // Сар бүрийн аль 7 хоногийн эхний бямба, ням сонгоно
  // Бүртгэл: Бямба 00:00 → Ням 23:59:59
  const we = firstWeekend(y, m);
  const satObj = we.find(x=>x.day===6);
  const sunObj = we.find(x=>x.day===0);
  if (!satObj || !sunObj) return null;

  const openUB  = new Date(y, m, satObj.date, 0, 0, 0);   // Бямба 00:00
  const closeUB = new Date(y, m, sunObj.date, 23, 59, 59); // Ням 23:59

  // UB time → UTC
  const TZ_OFFSET = 8 * 60; // UTC+8
  const open  = new Date(openUB.getTime()  - (openUB.getTimezoneOffset() + TZ_OFFSET) * 60000);
  const close = new Date(closeUB.getTime() - (closeUB.getTimezoneOffset() + TZ_OFFSET) * 60000);

  return {open, close, satDate: satObj.date, sunDate: sunObj.date};
}

function isRegOpen(now) {
  const w = getMonthlyRegWindow(now);
  if (!w) return false;
  return now >= w.open && now <= w.close;
}

function nextRegWindow(now) {
  // This month or next month
  const w = getMonthlyRegWindow(now);
  if (w && now < w.open) return w;
  // Next month
  const mn = new Date(now.toLocaleString('en-US',{timeZone:'Asia/Ulaanbaatar'}));
  const nextM = new Date(mn.getFullYear(), mn.getMonth()+1, 1);
  return getMonthlyRegWindow(nextM);
}

function pad2(n){ return String(n).padStart(2,'0'); }
function formatDate(d){
  const mn = new Date(d.toLocaleString('en-US',{timeZone:'Asia/Ulaanbaatar'}));
  return `${mn.getMonth()+1} сарын ${mn.getDate()}-нд`;
}

// ── Үндэсний бичгийн countdown ONLY ──
function updateScriptUI() {
  const now = new Date();
  const cd = document.getElementById('cdDisplay');
  if (!cd) return;
  const diff = CLASS_START - now;
  if (diff <= 0) {
    cd.textContent = '🟢 Эхэлсэн!';
    cd.style.color = '#4ade80';
  } else {
    const totalSec = Math.floor(diff / 1000);
    const days  = Math.floor(totalSec / 86400);
    const hours = Math.floor((totalSec % 86400) / 3600);
    const mins  = Math.floor((totalSec % 3600) / 60);
    const secs  = totalSec % 60;
    cd.textContent = days > 0
      ? `${days}өдөр ${pad2(hours)}:${pad2(mins)}:${pad2(secs)}`
      : `${pad2(hours)}:${pad2(mins)}:${pad2(secs)}`;
  }
}

// ── Монгол хэл + бусад хичээл — бүртгэлийн цонх ──
function updateHomeworkUI() {
  const now = new Date();
  const regEl    = document.getElementById('hwRegStatus');
  const tagEl    = document.getElementById('hwRegTag');
  const enrollBtn = document.getElementById('hwEnrollBtn');
  if (!regEl || !tagEl || !enrollBtn) return;

  const open = isRegOpen(now);
  const w = open ? getMonthlyRegWindow(now) : nextRegWindow(now);

  if (open && w) {
    const timeLeft = w.close - now;
    const hrs  = Math.floor(timeLeft/3600000);
    const mins = Math.floor((timeLeft%3600000)/60000);

    regEl.style.background = '#f0fdf4';
    regEl.style.color = '#065f46';
    regEl.innerHTML = `✅ <strong>Бүртгэл нээлттэй</strong> · ${hrs}ц ${mins}мин үлдсэн`;

    tagEl.textContent = '🟢 Бүртгэл нээлттэй';
    tagEl.style.background = '#d1fae5';
    tagEl.style.color = '#065f46';

    enrollBtn.disabled = false;
    enrollBtn.style.opacity = '1';
    enrollBtn.style.background = 'var(--amber)';
    enrollBtn.textContent = 'Бүртгүүлэх →';

  } else if (w) {
    const timeLeft = w.open - now;
    const days = Math.floor(timeLeft/86400000);
    const hrs  = Math.floor((timeLeft%86400000)/3600000);
    const mins = Math.floor((timeLeft%3600000)/60000);

    regEl.style.background = '#fef9f0';
    regEl.style.color = '#92400e';
    regEl.innerHTML = `🔒 <strong>Бүртгэл хаалттай</strong> · ${formatDate(w.open)} нээгдэнэ<br>
      <span style="font-size:13px;opacity:.8">${days > 0 ? days+'өдөр ' : ''}${pad2(hrs)}:${pad2(mins)} үлдсэн</span>`;

    tagEl.textContent = '🔒 Бүртгэл хаалттай';
    tagEl.style.background = '#fee2e2';
    tagEl.style.color = '#991b1b';

    enrollBtn.disabled = true;
    enrollBtn.style.opacity = '0.45';
    enrollBtn.style.background = '#9ca3af';
    enrollBtn.textContent = '🔒 Хаалттай';
  }
}

function handleHomeworkEnroll() {
  const now = new Date();
  if (!isRegOpen(now)) {
    const w = nextRegWindow(now);
    const msg = w ? `Бүртгэл ${formatDate(w.open)} 00:00 цагт нээгдэнэ.` : 'Бүртгэл одоогоор хаалттай байна.';
    showToast('🔒 ' + msg, 'error');
    return;
  }
  openCourseDetail('other');
}

// Init + секунд бүр шинэчлэх
updateScriptUI();
updateHomeworkUI();
setInterval(() => { updateScriptUI(); updateHomeworkUI(); }, 1000);

function toggleMobileNav(){
  document.getElementById('mobileNav').classList.toggle('open');
  document.getElementById('hamburger').classList.toggle('open');
}
function closeMobileNav(){
  document.getElementById('mobileNav').classList.remove('open');
  document.getElementById('hamburger').classList.remove('open');
}
document.addEventListener('click',function(e){
  const nav=document.getElementById('mobileNav');
  const btn=document.getElementById('hamburger');
  if(nav&&nav.classList.contains('open')){
    if(!nav.contains(e.target)&&!btn.contains(e.target))closeMobileNav();
  }
});
